"""Deterministic synthetic dataset."""
